#ifndef TIPOPRODUCTO_H
#define TIPOPRODUCTO_H

#include <stdlib.h>
#include <iostream>

using std::cin;
using std::cout;
using std::string;
using std::endl;

class TipoProducto
{
private:
    string nombre;
    int iva;
public:
    TipoProducto();
    TipoProducto(string nombre, int iva);

    void setIva(int iva);
    void setNombre(string nombre);
    int getIva();
    string getNombre();
};


#endif