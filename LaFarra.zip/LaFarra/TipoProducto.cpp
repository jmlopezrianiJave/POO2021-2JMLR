#include "TipoProducto.h"

TipoProducto::TipoProducto(){
    this->iva = 0;
    this->nombre = "";
}

TipoProducto::TipoProducto(string nombre, int iva){
    this->iva = iva;
    this->nombre = nombre;
}

void TipoProducto::setIva(int iva){
    this->iva = iva;
}

void TipoProducto::setNombre(string nombre){
    this->nombre = nombre;
}

int TipoProducto::getIva(){
    return this->iva;
}

string TipoProducto::getNombre(){
    return nombre;
}