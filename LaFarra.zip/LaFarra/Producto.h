#ifndef PRODUCTO_H
#define PRODUCTO_H

#include "TipoProducto.h"

class Producto
{
private:
    TipoProducto tipoProducto;
    int codigo, cantidadUnidades;
    float precio, costo;
    string nombre;
public:
//constructores
    Producto();
    Producto(TipoProducto tipoProducto, int codigo, int cantidadUnidades, float precio, float costo);
//metodos
    void setTipoProducto(TipoProducto tipoProducto);
    void setCodigo(int codigo);
    void setCantidadUnidades(int cantidadUnidades);
    void
};


#endif